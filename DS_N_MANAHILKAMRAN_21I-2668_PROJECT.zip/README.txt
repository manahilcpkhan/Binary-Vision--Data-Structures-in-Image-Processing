Add the pgm file you want to read in the folder.
Import the pgm file.

Run the code.
On terminal, enter the pgm file name you want to read.
select which question you want to run by typing the number.
press enter.
program will run for that question.
Type 1 and press enter to get the output of question 1 and check output in file Input.pgm
Type 2 and press enter to execute question 2 and check output in file queueImage.pgm
Type 3 and press enter to execute question 3 and check output in file stackImage.pgm
Type 4 and press enter to execute question 4 and check the saved rlc list in file RLC.rlc 
Check the saved Image after rlc converion to image in RLCImage.pgm. 
FOR the negative image check the file NegativeRLCImage.pgm
Type 5 and press enter to execute question 5
Type 6 and press enter to execute question 6

Type 0 to exit program.